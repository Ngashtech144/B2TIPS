import React, { useState } from "react";
import { Text, View, TextInput, Button, ScrollView } from "react-native";

export default function App() {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [transactionCode, setTransactionCode] = useState("");
  const [isPaid, setIsPaid] = useState(false);
  const [userFeedback, setUserFeedback] = useState("");

  const handlePayment = () => {
    if (transactionCode.trim() !== "") {
      setIsPaid(true);
    }
  };

  return (
    <ScrollView style={{ padding: 20, backgroundColor: "#e6f4ea" }}>
      <Text style={{ fontSize: 24, fontWeight: "bold", textAlign: "center", marginBottom: 20 }}>
        B2TIPS Football Predictions
      </Text>

      <View style={{ marginBottom: 20 }}>
        <Text style={{ fontSize: 18, fontWeight: "bold" }}>Live Matches</Text>
        <Text>Man United vs Chelsea - 1st Half (1-0)</Text>
        <Text>Real Madrid vs Barcelona - 2nd Half (2-2)</Text>
        <Text>Juventus vs Napoli - 30' Min (0-0)</Text>
      </View>

      <View style={{ marginBottom: 20 }}>
        <Text style={{ fontSize: 18, fontWeight: "bold" }}>Upcoming Matches</Text>
        <Text>Arsenal vs Liverpool - 18:00 GMT</Text>
        <Text>Inter Milan vs AC Milan - 20:00 GMT</Text>
        <Text>Atletico Madrid vs Sevilla - 21:30 GMT</Text>
      </View>

      <View style={{ marginBottom: 20 }}>
        <Text style={{ fontSize: 18, fontWeight: "bold" }}>Free Predictions</Text>
        <Text>Man United vs Chelsea - Over 2.5 Goals</Text>
        <Text>Real Madrid vs Barcelona - Draw</Text>
      </View>

      <View style={{ marginBottom: 20 }}>
        <Text style={{ fontSize: 18, fontWeight: "bold" }}>VIP Predictions (KES 70 for 5 Games)</Text>
        {!isPaid ? (
          <>
            <Text>Send KES 70 to +254710363734 via M-Pesa Pochi la Biashara.</Text>
            <Text>NAME: KELVIN SHIDA</Text>
            <TextInput
              placeholder="Enter phone number"
              value={phoneNumber}
              onChangeText={setPhoneNumber}
              style={{ borderWidth: 1, marginVertical: 5, padding: 8 }}
            />
            <TextInput
              placeholder="Enter transaction code"
              value={transactionCode}
              onChangeText={setTransactionCode}
              style={{ borderWidth: 1, marginVertical: 5, padding: 8 }}
            />
            <Button title="Verify Payment" onPress={handlePayment} />
          </>
        ) : (
          <>
            <Text>Liverpool vs Man City - Both Teams to Score</Text>
            <Text>Juventus vs Napoli - Juventus to Win</Text>
            <Text>Arsenal vs Tottenham - Over 2.5 Goals</Text>
            <Text>Bayern Munich vs Dortmund - Bayern to Win</Text>
            <Text>PSG vs Lyon - PSG to Win</Text>
          </>
        )}
      </View>

      <View style={{ marginBottom: 20 }}>
        <Text style={{ fontSize: 18, fontWeight: "bold" }}>User Feedback</Text>
        <TextInput
          placeholder="Leave your feedback or suggestions..."
          value={userFeedback}
          onChangeText={setUserFeedback}
          style={{ borderWidth: 1, padding: 8, marginBottom: 10 }}
          multiline
        />
        <Button title="Submit Feedback" />
      </View>
    </ScrollView>
  );
}